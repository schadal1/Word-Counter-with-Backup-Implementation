package wordCount.util;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputFileProcessor {

	private  Scanner input;
	
	private static InputFileProcessor uniqueInstance;
	private InputFileProcessor(String inputFile)
	{
		try {

	    	input = new Scanner(new File(inputFile));	
	    } 
	    catch (IOException e) {
	        e.printStackTrace();
	        System.exit(0);
	    }	
	}
	public static InputFileProcessor getInstance(String inputFile)
	{	
		
		if(uniqueInstance==null)
		{
			uniqueInstance=new InputFileProcessor(inputFile);			
		} 
		
		return uniqueInstance;		
	}
	public String getNext()
	{
		String s=input.next();
		//Pattern p = Pattern.compile("[\\w']+");
		Pattern p = Pattern.compile("\\w+");
		Matcher m = p.matcher(s);
		m.find();
		return s.substring(m.start(), m.end());
	}
	public boolean hasNext()
	{
		return input.hasNext();
	}
}
