package wordCount.util;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;



public class OutputFileProcessor {

	
	private  FileWriter output;
	private static OutputFileProcessor uniqueInstance=null;
	private OutputFileProcessor(String outputFile)
	{
		try {
	    		    	setOutput(new FileWriter(new File(outputFile),false));
	    		   
	    } 
	    catch (IOException e) {
	        e.printStackTrace();
	        System.exit(0);
	    }
		/*if(Logger.getDebugValue().equals(Logger.DebugLevel.four)){
			
			Logger.writeMessage("FileProcessor Constructor invoked",Logger.DebugLevel.four );
		}*/
	}
	public static  OutputFileProcessor getInstance(String outputFile)
	{	
		
		//if(uniqueInstance==null)
		//{
			uniqueInstance=new OutputFileProcessor(outputFile);			
		//} 
		
		return uniqueInstance;
	}
	public FileWriter getOutput() {
		return output;
	}
	public void setOutput(FileWriter output) {
		this.output = output;
	}
	public void writeToFile(String s) throws IOException
	{
		this.output.write(s);
		this.output.write(System.getProperty( "line.separator" ));
	}
	public void close() throws IOException
	{
		this.output.close();
	}
	public void flush() throws IOException
	{
		this.output.flush();
	}
	
}