package wordCount.visitors;

public interface Visitor{

	int Zero=0;
	public void visit(visitable visit);
}
