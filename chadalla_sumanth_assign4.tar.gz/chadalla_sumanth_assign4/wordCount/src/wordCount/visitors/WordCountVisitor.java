package wordCount.visitors;
import java.io.IOException;

import wordCount.dsForStrings.Node;
import wordCount.util.OutputFileProcessor;

public class WordCountVisitor implements Visitor{
	private OutputFileProcessor ofp;
	private int NoOfDistinctWords;
	private int NoOfWords;
	private int NoOfCharacters;
	public WordCountVisitor(String outputFile)
	{
		ofp=OutputFileProcessor.getInstance(outputFile);
		
	}

	
	public void visit(visitable visit) {
		
		NoOfDistinctWords=Zero;
		NoOfWords=Zero;
		NoOfCharacters=Zero;
		inOrder(visit.getRoot());
		
		try {
			write("\nTotal No Of Words:"+NoOfWords+"\n");
			write("\nTotal No Of DistinctWords:"+NoOfDistinctWords+"\n");
			write("\nTotal No Of Characters:"+NoOfCharacters+"\n");
			ofp.flush();
			ofp.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		//System.out.println("Total No Of Words:"+NoOfWords);
		//System.out.println("Total No Of DistinctWords:"+NoOfDistinctWords);
		//System.out.println("Total No Of Characters:"+NoOfCharacters);	
	
	}
	public void write(String InputString) throws IOException
	{
		ofp.writeToFile(InputString);
	}
	public void inOrder(Node root) {  
		  if(root !=  null) {  
		   inOrder((Node) root.getLeftChild());  
		   //Visit the node by Printing the node data    
		  // System.out.printf("'%s'  count: %d\n",root.getUniqueWord(),root.getCount());
		   NoOfDistinctWords=NoOfDistinctWords+1;
		   NoOfWords=NoOfWords+root.getCount();
		   NoOfCharacters=NoOfCharacters+(root.getUniqueWord().length()*root.getCount());
		   inOrder((Node) root.getRightChild());  
		  }  
		 }

}
