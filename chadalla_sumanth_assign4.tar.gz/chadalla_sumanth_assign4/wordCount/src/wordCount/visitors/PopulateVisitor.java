package wordCount.visitors;

import wordCount.dsForStrings.Node;
import wordCount.dsForStrings.Observer;
import wordCount.util.InputFileProcessor;

public class PopulateVisitor implements Visitor{

	private InputFileProcessor ifp;
	public PopulateVisitor(String inputFile)
	{
		ifp=InputFileProcessor.getInstance(inputFile);
	}	
	public void visit(visitable visit) {
		while(ifp.hasNext())
		{
			if(visit.getRoot()==null)
			{
				Node temp=new Node();
				temp.setUniqueWord(ifp.getNext());
				temp.setCount(1);
				temp.setLeftChild(null);
				temp.setParent(null);
				temp.setRightChild(null);
				visit.assignRoot(temp);
				temp.setBackup(new Observer[2]);
			}
			else
			{
				Node temp=visit.getRoot();
				temp.InsertNode(ifp.getNext(), temp);				
			}
		}
		
	}
	 	

}
