package wordCount.visitors;

import wordCount.driver.Driver;
import wordCount.dsForStrings.BackupNode;
import wordCount.dsForStrings.Node;

public class UpdateVisitor implements Visitor{

	int count=0;
	public void visit(visitable visit) {
		Node root=visit.getRoot();
		updator(root);
		System.out.println("total words of basic Tree "+count);
		count=0;
		updatorBackup(Driver.BackupNode);
		System.out.println("total words of backup Tree "+count);
	}
	public void updator(Node root)
	{
		if(root!=null)
		{
			root.setCount(root.getCount()+1);
			count=count+root.getCount();
			if(root.getLeftChild()!=null)
			{
				updator((Node) root.getLeftChild());
			}
			if(root.getRightChild()!=null)
			{
				updator( (Node)root.getRightChild());	
			}
		}
	}
	public void updatorBackup(BackupNode backupNode)
	{
		if(backupNode!=null)
		{
			backupNode.setCount(backupNode.getCount()+1);
			count=count+backupNode.getCount();
			if(backupNode.getLeftChild()!=null)
			{
				updatorBackup( backupNode.getLeftChild());
			}
			if(backupNode.getRightChild()!=null)
			{
				updatorBackup( backupNode.getRightChild());	
			}
		}
	}

}
