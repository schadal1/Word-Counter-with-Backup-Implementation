package wordCount.visitors;

import wordCount.dsForStrings.Node;

public interface visitable {


	public void assignRoot(Node nodeIn);	
	public Node getRoot();
	public void accept(Visitor visitor);
}
