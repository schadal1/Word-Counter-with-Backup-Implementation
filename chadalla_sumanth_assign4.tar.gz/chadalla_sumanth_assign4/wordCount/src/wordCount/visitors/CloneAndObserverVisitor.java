package wordCount.visitors;

import wordCount.driver.Driver;
import wordCount.dsForStrings.BackupNode;
import wordCount.dsForStrings.Node;

public class CloneAndObserverVisitor implements Visitor{

	
	public void visit(visitable visit) {
		Node root=visit.getRoot();
		
	
		//Cloner(root);
		
		Driver.BackupNode=Cloner(root);
		
		//inOrder(Driver.BackupNode);
		
	}
	public void inOrder(BackupNode root) {  
		  if(root !=  null) {  
		   inOrder(root.getLeftChild());  
		   //Visit the node by Printing the node data    
		  System.out.printf("'%s'  count: %d\n",root.getUniqueWord(),root.getCount());
		   inOrder(root.getRightChild());  
		  }  
		 }
	public BackupNode Cloner(Node NodeIn)	
	{
		if(NodeIn!=null)
		{
			BackupNode back =(BackupNode) NodeIn.clone();
			NodeIn.registerObserver(back);
		
		if((Node)NodeIn.getLeftChild()!=null)
		{
			back.setLeftChild(Cloner((Node) NodeIn.getLeftChild()));
		}
		if((Node)NodeIn.getRightChild()!=null)
		{
			back.setRightChild(Cloner((Node) NodeIn.getRightChild()));
		}
		return (BackupNode) back;
		}
		return null;
	}

}
