package wordCount.driver;
import java.io.FileNotFoundException;
import java.io.IOException;

import wordCount.dsForStrings.Tree;
import wordCount.visitors.CloneAndObserverVisitor;
import wordCount.visitors.PopulateVisitor;
import wordCount.visitors.UpdateVisitor;
import wordCount.visitors.WordCountVisitor;

public class Driver {
	public static wordCount.dsForStrings.BackupNode BackupNode=null;
	public static void main(String[] args) throws NumberFormatException, InterruptedException, FileNotFoundException,IOException 
	{
		
		if(args.length!=3)
		{
			System.out.println("Wrong No of Command Line Arguments,Please enter Correct number of Arguments ");
		}
		else	
		{	
			long n=(long)Integer.parseInt(args[2]);
			String inputFile=args[0];
			String outputFile=args[1];
			long startTime = System.currentTimeMillis();	
			Tree BaseTree=new Tree();
			//Create Elements
			for(int i=0;i<n;i++)
			{
			
			//PopulateVisitor Fin=new FileInfoForTree(args[0]);
			//TreeInfoForCount Tin=new TreeInfoForCount(args[1]);
			
			// create the visitors
			PopulateVisitor Populator=new PopulateVisitor(inputFile);
			WordCountVisitor WordCounter=new WordCountVisitor(outputFile);
			
			//Visit the Elements	
			BaseTree.accept(Populator);
			BaseTree.accept(WordCounter);
			}
			long finishTime = System.currentTimeMillis();
			long totalTime=finishTime-startTime;
			System.out.println((totalTime/n)+" milli seconds");
			CloneAndObserverVisitor Cloner=new CloneAndObserverVisitor();
			BaseTree.accept(Cloner);
			
			UpdateVisitor update=new UpdateVisitor();
			BaseTree.accept(update);
			
		}
	}
}
