package wordCount.dsForStrings;

public class BackupNode implements NodeInterface,Observer{

	private String UniqueWord;
	private int count;
	private BackupNode leftChild;
	private BackupNode rightChild;
	private BackupNode parent;
	public String getUniqueWord() {
		return UniqueWord;
	}
	public void setUniqueWord(String uniqueWord) {
		UniqueWord = uniqueWord;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public BackupNode getLeftChild() {
		return leftChild;
	}
	public void setLeftChild(BackupNode leftChild) {
		this.leftChild = leftChild;
	}
	public BackupNode getRightChild() {
		return rightChild;
	}
	public void setRightChild(BackupNode rightChild) {
		this.rightChild = rightChild;
	}
	public BackupNode getParent() {
		return parent;
	}
	public void setParent(BackupNode parent) {
		this.parent = parent;
	}
	@Override
	public void setLeftChild(NodeInterface leftChild) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setRightChild(NodeInterface leftChild) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void update(int newCount) {
		// TODO Auto-generated method stub
		this.setCount(newCount);
		
	}
}
