package wordCount.dsForStrings;

public interface SubjectInterface {

	public void registerObserver(Observer Node);
	public void notification();
}
