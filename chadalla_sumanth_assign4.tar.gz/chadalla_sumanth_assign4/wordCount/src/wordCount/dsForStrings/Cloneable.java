package wordCount.dsForStrings;

public interface Cloneable {
	public Object clone();
}
