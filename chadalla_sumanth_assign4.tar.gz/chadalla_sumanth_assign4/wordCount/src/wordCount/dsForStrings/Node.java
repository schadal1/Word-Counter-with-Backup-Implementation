package wordCount.dsForStrings;

public class Node implements Cloneable,NodeInterface,SubjectInterface{

	private String UniqueWord;
	private int count;
	private Node leftChild;
	private Node rightChild;
	private Node parent;
	private Observer backup[];
	public String getUniqueWord() {
		return UniqueWord;
	}
	public void setUniqueWord(String uniqueWord) {
		UniqueWord = uniqueWord;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public NodeInterface getLeftChild() {
		return leftChild;
	}
	public void setLeftChild(Node leftChild) {
		this.leftChild = leftChild;
	}
	public NodeInterface getRightChild() {
		return rightChild;
	}
	public void setRightChild(Node rightChild) {
		this.rightChild = rightChild;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public Observer[] getBackup() {
		return backup;
	}
	public void setBackup(Observer[] backup) {
		this.backup = backup;
	}
	public void InsertNode(String inputString,Node NodeIn)
	{
		//-ve for left child, +ve for right child and 0 for a match
		int ChooseNext=NodeIn.getUniqueWord().compareTo(inputString);
		if(ChooseNext==0)
		{
			int currCount=NodeIn.getCount();
			currCount=currCount+1;
			NodeIn.setCount(currCount);
			return;
		}
		else if(ChooseNext<0)
		{
			if(NodeIn.getLeftChild()!=null)
			{
				NodeIn=(Node) NodeIn.getLeftChild();
				InsertNode(inputString,NodeIn);
				return;
			}
			else
			{
				Node temp=new Node();
				temp.setUniqueWord(inputString);
				temp.setCount(1);
				temp.setLeftChild(null);
				temp.setParent(NodeIn);
				temp.setRightChild(null);
				temp.setBackup(new Observer[2]);
				NodeIn.setLeftChild(temp);
				return;
			}
		}
		else
		{
			if(NodeIn.getRightChild()!=null)
			{
				NodeIn=(Node) NodeIn.getRightChild();
				InsertNode(inputString,NodeIn);
				return;
			}
			else
			{
				Node temp=new Node();
				temp.setUniqueWord(inputString);
				temp.setCount(1);
				temp.setLeftChild(null);
				temp.setRightChild(null);
				temp.setParent(NodeIn);
				temp.setBackup(new Observer[2]);
				NodeIn.setRightChild(temp);
				return;
			}
			
		}		
	}
	public Object clone()
	{
		BackupNode BackupClone=new BackupNode();
		BackupClone.setUniqueWord(this.UniqueWord);
		BackupClone.setCount(this.getCount());
		
		return BackupClone;		
	}

	public void setLeftChild(NodeInterface leftChild) {
		
	}
	
	public void setRightChild(NodeInterface leftChild) {
		
	}
	public void registerObserver(Observer Node) {
		backup[0]=Node;
	}
	public void notification() {
		backup[0].update(this.getCount());
	}
	
	
}