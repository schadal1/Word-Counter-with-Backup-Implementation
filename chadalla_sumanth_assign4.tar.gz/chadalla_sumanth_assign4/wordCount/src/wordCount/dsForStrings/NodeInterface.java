package wordCount.dsForStrings;

public interface NodeInterface {
	public String getUniqueWord();
	public void setUniqueWord(String uniqueWord) ;
	public int getCount();
	public void setCount(int count);
	public void setLeftChild(NodeInterface leftChild);
	public NodeInterface getRightChild();
	public void setRightChild(NodeInterface leftChild);
	public NodeInterface getLeftChild();
}
