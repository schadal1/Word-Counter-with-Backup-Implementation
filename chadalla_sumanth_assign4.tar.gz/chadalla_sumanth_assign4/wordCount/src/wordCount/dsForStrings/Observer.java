package wordCount.dsForStrings;

public interface Observer {

	public void update(int newCount);
}
