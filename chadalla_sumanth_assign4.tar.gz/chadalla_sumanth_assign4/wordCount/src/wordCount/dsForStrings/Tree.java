package wordCount.dsForStrings;

import wordCount.visitors.Visitor;
import wordCount.visitors.visitable;

public class Tree implements visitable {
	private Node Root;
	private Node BackupRoot;
	public void accept(Visitor visitor) {

		visitor.visit(this);
		
	}
	
	public void assignRoot(Node nodeIn) {
		Root=nodeIn;		
	}
	public Node getRoot()
	{
		return Root;
	}

	public Node getBackupRoot() {
		return BackupRoot;
	}

	public void setBackupRoot(Node backupRoot) {
		BackupRoot = backupRoot;
	}

}
